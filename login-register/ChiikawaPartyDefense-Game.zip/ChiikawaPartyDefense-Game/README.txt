Chiikawa Party Defense - Local Game Client

SYSTEM REQUIREMENTS:
- Windows 7 or higher
- Java Runtime Environment (JRE) 8 or higher
- Internet connection for login and score sync

INSTALLATION:
1. Extract all files to a folder
2. Double-click ChiikawaPartyDefense.jar to start the game
3. If Java is not installed, download from: https://java.com

GAMEPLAY:
- Login with your web account
- Play offline after authentication
- Scores automatically sync to online leaderboard

TROUBLESHOOTING:
- If game doesn't start: Install/update Java
- If login fails: Check internet connection
- For support: Visit our website

Version: 1.0
</README.txt>